# Snap Editor

A phone-friendly photo editor that runs entirely in the browser. Nothing is uploaded to a server.

Features: take photos with the camera or upload, gallery of your photos, one-tap Compress (1280 px, JPEG at 70 to 80% quality, about 100 KB) with revert to original, text, textbox and arrow, date stamp, font size and style, crop, rotate, brightness and contrast, share, and save as JPG or PDF.

## Publish on GitHub Pages
1. Create a new repository on GitHub.
2. Upload every file in this folder to the repository root: `index.html`, `manifest.json`, `README.md` and all the `.png` icons.
3. Go to Settings, then Pages. Under Branch choose `main` and `/ (root)`, then Save.
4. After a minute the app is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

Open the link on your phone and choose Add to Home Screen to install it like an app. The camera needs HTTPS, which GitHub Pages provides. PDF export loads its library from the internet, so it needs a connection.
